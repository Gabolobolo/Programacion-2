package Calculadora;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args)
    {
        String nombre, apellido;
        Scanner sc = new Scanner(System.in);
        System.out.println("Buenos dias");
        System.out.print("Ingrese su nombre: ");
        nombre = sc.nextLine();
        System.out.print("Ingrese su apellido: ");
        apellido = sc.nextLine();
        System.out.println("Su nombre es: "+nombre+ " " +apellido);
    }
}
